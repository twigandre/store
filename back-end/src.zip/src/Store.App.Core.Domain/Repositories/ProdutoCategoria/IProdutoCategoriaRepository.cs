﻿using Store.App.Core.Domain.Entitites;

namespace Store.App.Core.Domain.Repositories
{
    public interface IProdutoCategoriaRepository : IGenericRepository<ProdutoCategoriaEntity>
    {
    }
}
