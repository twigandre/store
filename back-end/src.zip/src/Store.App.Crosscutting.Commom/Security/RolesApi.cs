﻿namespace Store.App.Crosscutting.Commom.Security
{
    public class RolesApi
    {
        public const string Autenticado = "autenticado";
    }
}
