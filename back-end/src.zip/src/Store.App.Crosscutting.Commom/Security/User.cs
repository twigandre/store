﻿namespace Store.App.Crosscutting.Commom.Security
{
    public class User
    {
        public string NameId { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
        public string EmailUsuarioLogado { get; set; }
    }
}
