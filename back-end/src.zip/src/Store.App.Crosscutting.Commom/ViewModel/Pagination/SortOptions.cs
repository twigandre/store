﻿namespace Store.App.Crosscutting.Commom.ViewModel.Pagination
{
    public class SortOptions
    {
        public bool? Reverse { get; set; }
        public string? Sort { get; set; }
    }
}
