﻿namespace Store.App.Crosscutting.Commom.ViewModel.Core.Filial
{
    public class FilialVM
    {
        public int Id { get; set; }

        public string Nome { get; set; }
    }
}
