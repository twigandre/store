﻿namespace Store.App.Crosscutting.Commom.ViewModel.Core.Produto
{
    public class AvaliacaoVM
    {
        public int Nota { get; set; } = 0;
        public int NumeroVendas { get; set; } = 0;
    }
}
