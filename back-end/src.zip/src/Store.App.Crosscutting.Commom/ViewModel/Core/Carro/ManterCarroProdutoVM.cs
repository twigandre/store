﻿namespace Store.App.Crosscutting.Commom.ViewModel.Core.Carro
{
    public class ManterCarroProdutoVM
    {
        public int IdCarro { get; set; }
        public int IdProduto { get; set; }
    }
}
