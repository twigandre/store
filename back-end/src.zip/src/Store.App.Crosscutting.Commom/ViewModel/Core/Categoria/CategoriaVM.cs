﻿namespace Store.App.Crosscutting.Commom.ViewModel.Core.Categoria
{
    public class CategoriaVM
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
