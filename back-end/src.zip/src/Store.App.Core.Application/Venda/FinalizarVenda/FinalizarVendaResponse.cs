﻿using Store.App.Crosscutting.Commom.ViewModel;

namespace Store.App.Core.Application.Venda.FinalizarVenda
{
    public class FinalizarVendaResponse : RequestResponseVM
    {
    }
}
