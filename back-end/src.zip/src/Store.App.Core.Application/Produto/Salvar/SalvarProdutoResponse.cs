﻿using Store.App.Crosscutting.Commom.ViewModel;

namespace Store.App.Core.Application.Produto.Salvar
{
    public class SalvarProdutoResponse : RequestResponseVM
    {
        public int Id { get; set; }
    }
}
