﻿using Store.App.Crosscutting.Commom.ViewModel;

namespace Store.App.Core.Application.Produto.Apagar
{
    public class ApagarProdutoResponse : RequestResponseVM
    {
    }
}
