﻿using Store.App.Crosscutting.Commom.ViewModel;

namespace Store.App.Core.Application.Carro.Produto.RemoverProduto
{
    public class RemoverProdutoResult : RequestResponseVM
    {
    }
}
