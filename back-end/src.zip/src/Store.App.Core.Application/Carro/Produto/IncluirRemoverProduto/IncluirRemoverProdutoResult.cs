﻿using Store.App.Crosscutting.Commom.ViewModel;

namespace Store.App.Core.Application.Carro.Produto.IncluirRemoverProduto
{
    public class IncluirRemoverProdutoResult : RequestResponseVM
    {       
    }
}
