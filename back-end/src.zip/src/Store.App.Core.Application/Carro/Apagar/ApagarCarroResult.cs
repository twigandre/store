﻿using Store.App.Crosscutting.Commom.ViewModel;

namespace Store.App.Core.Application.Carro.Apagar
{
    public class ApagarCarroResult : RequestResponseVM
    {
    }
}
