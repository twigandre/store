﻿namespace Store.App.Crosscutting.Commom.ViewModel.Core.Application.Usuario.Salvar
{
    public class SalvarUsuarioResponse : RequestResponseVM
    {
        public int Id { get; set; }
    }
}
