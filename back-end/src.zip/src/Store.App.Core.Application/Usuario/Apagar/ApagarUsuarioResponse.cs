﻿using Store.App.Crosscutting.Commom.ViewModel;

namespace Store.App.Core.Application.Usuario.Apagar
{
    public class ApagarUsuarioResponse : RequestResponseVM
    {
    }
}
